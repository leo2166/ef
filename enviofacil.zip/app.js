console.log("DEBUG: app.js cargado y ejecutándose. MODO REDIRECT v3.");

// --- FUNCIONES DE UI ---

function actualizarUIAutenticado(token) {
  console.log("DEBUG: UI-UPDATE: Actualizando a 'Autenticado'.");
  localStorage.setItem('gmail_access_token', token);

  document.getElementById('estado-autenticacion').innerText = '¡Autenticación exitosa!';
  document.getElementById('estado-autenticacion').style.color = 'green';
  document.getElementById('signout_button').style.display = 'block';
  const signinDiv = document.querySelector('.g_id_signin');
  if (signinDiv) signinDiv.style.display = 'none';
  
  const btnContinuar = document.getElementById('btn-continuar');
  btnContinuar.disabled = false;
  btnContinuar.classList.add('btn-activo');
}

function actualizarUINoAutenticado() {
    console.log("DEBUG: UI-UPDATE: Actualizando a 'No Autenticado'.");
    document.getElementById('estado-autenticacion').innerText = 'Esperando autenticación...';
    document.getElementById('estado-autenticacion').style.color = 'orange';
    document.getElementById('signout_button').style.display = 'none';
    const signinDiv = document.querySelector('.g_id_signin');
    if (signinDiv) signinDiv.style.display = 'block';

    const btnContinuar = document.getElementById('btn-continuar');
    btnContinuar.disabled = true;
    btnContinuar.classList.remove('btn-activo');
}

// --- FUNCIONES DE AUTENTICACIÓN ---

function signOut() {
  console.log("DEBUG: AUTH: Ejecutando signOut().");
  const token = localStorage.getItem('gmail_access_token');
  if (token) {
      google.accounts.oauth2.revoke(token, () => {
        console.log('DEBUG: AUTH: El token de acceso ha sido revocado en Google.');
      });
  }
  localStorage.removeItem('gmail_access_token');
  actualizarUINoAutenticado();
}

// --- CÓDIGO PRINCIPAL QUE SE EJECUTA AL CARGAR LA PÁGINA ---

window.onload = function () {
  console.log("DEBUG: CORE: window.onload FUE LLAMADO.");

  // Asignar eventos a los botones
  document.getElementById('signout_button').onclick = signOut;
  document.getElementById('btn-continuar').addEventListener('click', () => {
    if (!document.getElementById('btn-continuar').disabled) {
      console.log("DEBUG: CORE: Botón 'Continuar' presionado. Redirigiendo a pantalla2.html");
      window.location.href = 'pantalla2.html';
    }
  });

  // 1. Inicializar el cliente de token para MANEJAR LA RESPUESTA de la redirección.
  // Este cliente se activa automáticamente si la URL contiene una respuesta de Google.
  google.accounts.oauth2.initTokenClient({
    client_id: '153822552005-9rgnskk4tvfoaakr4hcnlnssts0scq0r.apps.googleusercontent.com',
    scope: 'https://www.googleapis.com/auth/gmail.send',
    callback: (tokenResponse) => {
      console.log("DEBUG: CORE: El callback de initTokenClient FUE LLAMADO (¡Éxito!).");
      if (tokenResponse && tokenResponse.access_token) {
        // ¡Este es el caso de éxito después de la redirección!
        actualizarUIAutenticado(tokenResponse.access_token);
      } else {
        console.error("DEBUG: CORE: ERROR: La respuesta del token post-redirección no contiene el 'access_token'.");
        actualizarUINoAutenticado();
      }
    }
  }).requestAccessToken(); // Intentamos obtener un token silenciosamente al cargar.

  // 2. Revisamos si ya tenemos una sesión guardada de antes.
  const tokenGuardado = localStorage.getItem('gmail_access_token');
  if (tokenGuardado) {
    console.log("DEBUG: CORE: Se encontró un token en localStorage. Sesión persistente.");
    actualizarUIAutenticado(tokenGuardado);
  } else {
    // 3. Si no hay sesión, configuramos el botón de inicio de sesión.
    console.log("DEBUG: CORE: No hay token. Inicializando el botón de Google ID.");
    google.accounts.id.initialize({
      client_id: '153822552005-9rgnskk4tvfoaakr4hcnlnssts0scq0r.apps.googleusercontent.com',
      login_uri: "https://ef-inky.vercel.app/", // Asegúrate que esta es la URL exacta de despliegue
      ux_mode: "redirect"
    });
    
    actualizarUINoAutenticado();
    console.log("DEBUG: CORE: Renderizando el botón de Google.");
    google.accounts.id.renderButton(
      document.querySelector('.g_id_signin'),
      { theme: 'filled_blue', size: 'large', shape: 'pill', text: 'authorize' }
    );
  }
};

console.log("DEBUG: Fin del script app.js.");